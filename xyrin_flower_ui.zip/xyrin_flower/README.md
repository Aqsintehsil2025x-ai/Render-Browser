# Xyrin Flower — Premium AI Desktop Interface

Dark navy · blue-violet · botanical identity

---

## Dosya Değişiklikleri / File Manifest

### Eklenen dosyalar (Added)

| Dosya | Açıklama |
|---|---|
| `main.py` | Yeni giriş noktası — eski `main.py` yerine geçer veya sarar |
| `ui/__init__.py` | Python paketi init |
| `ui/theme.py` | Renk, tipografi ve boyut tokenları |
| `ui/widgets.py` | Özel widget'lar: balon, kaydırma çerçevesi, yan çubuk öğeleri |
| `ui/svg_render.py` | SVG → Tkinter PhotoImage dönüştürücü (cairosvg / svglib ile çalışır, ikisi de yoksa canvas çizer) |
| `ui/app_ui.py` | **Ana UI sınıfı** `XyrinUI(tk.Tk)` |
| `assets/xyrin_logo.svg` | Xyrin Flower vektör logosu (mavi-menekşe çiçek) |
| `assets/xyrin_icon.svg` | 512×512 uygulama ikonu (Linux masaüstü için) |
| `xyrin-flower.desktop` | Linux uygulama başlatıcı (`.desktop` dosyası) |

### Değiştirilmeyen dosyalar (Unchanged)

Mevcut Python dosyalarınız (`backend.py`, `model.py`, llama.cpp çağrıları, model indirme mantığı, API istekleri vb.) **hiçbir şekilde değiştirilmemiştir.**

---

## Kurulum / Installation

```bash
# İsteğe bağlı: SVG'yi yüksek kalitede render etmek için
pip install cairosvg pillow
# veya
pip install svglib reportlab pillow

# Uygulamayı çalıştır
python3 main.py
```

> SVG kütüphanesi yoksa logo, Tkinter canvas üzerine çizilir — uygulama tamamen çalışmaya devam eder.

---

## Backend Entegrasyonu / Backend Integration

`main.py` içindeki `generate_reply()` fonksiyonunu mevcut AI çağrısıyla değiştirin:

```python
def on_user_message(text: str):
    app.show_typing()
    app.set_status("Yanıt üretiliyor…")

    # ↓ BURAYA mevcut llama.cpp / Ollama / API çağrınızı yazın
    reply = your_existing_backend_call(text)

    app.hide_typing()
    app.receive_message(reply, sender="ai")
    app.set_status("Hazır · Offline AI")
```

### UI API

```python
app = XyrinUI()

# Backend'den UI'ya
app.set_send_callback(fn)          # fn(text: str) — kullanıcı gönderdiğinde çağrılır
app.receive_message(text, "ai")    # AI yanıtını ekle
app.show_typing()                  # Yazıyor animasyonu göster
app.hide_typing()                  # Yazıyor animasyonunu gizle
app.set_status("Meşgul…")          # Alt durum çubuğunu güncelle
app.set_model_name("Llama 3 8B")   # Model adını güncelle
```

---

## Linux Masaüstü İkonu / Desktop Icon

```bash
# /opt konumuna kopyala (veya proje dizininize göre ayarlayın)
sudo cp -r . /opt/xyrin-flower

# .desktop dosyasını yükle
cp xyrin-flower.desktop ~/.local/share/applications/
update-desktop-database ~/.local/share/applications/
```

---

## Özellikler / Features

- **Karanlık Donanım**: Derin lacivert arkaplan, mavi-menekşe vurgular
- **Tipografi**: Inter / Segoe UI, okunabilir yazı ölçeği
- **Mesaj Balonları**: Kullanıcı ve AI için ayrı yumuşak-köşeli balonlar
- **Yazıyor Göstergesi**: Nabız atan üç nokta animasyonu
- **Otomatik Kaydırma**: En yeni mesaja otomatik kayar
- **Enter Gönder / Shift+Enter Yeni Satır**: Klavye kısayolu
- **Dinamik Yükseklik**: Kompozitör, içeriğe göre büyür (2–6 satır)
- **Yan Çubuk**: Logo, yeni sohbet, çalışma alanı seçici, sohbet geçmişi, ayarlar
- **Durum Çubuğu**: Canlı durum metni (hazır / üretiyor / başlatılıyor)
- **Türkçe Arayüz**: Tüm etiketler Türkçe

---

*Xyrin Flower · Offline AI Experience*
