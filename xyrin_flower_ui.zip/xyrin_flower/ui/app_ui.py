"""
Xyrin Flower — Premium AI Desktop Interface
ui/app_ui.py

Drop-in UI replacement for the existing application.
Attach to backend by calling XyrinUI.set_send_callback(fn).
fn(text: str) → None  — called when user submits a message.
Call XyrinUI.receive_message(text, sender) to append a message.
"""
from __future__ import annotations
import tkinter as tk
from tkinter import ttk
from pathlib import Path
import threading

from ui import theme as T
from ui.widgets import (
    SmoothScrollFrame, MessageBubble, TypingIndicator,
    SidebarItem, SendButton, IconButton
)
from ui.svg_render import draw_flower_logo, load_svg_as_photo

ASSETS = Path(__file__).parent.parent / "assets"


# ═════════════════════════════════════════════════════════════════════════════
#  XyrinUI  — the main application window class
# ═════════════════════════════════════════════════════════════════════════════

class XyrinUI(tk.Tk):
    """
    Call XyrinUI().mainloop() to launch.
    Wire backend via:
        app.set_send_callback(my_function)   # called with (user_text: str)
    Display AI reply via:
        app.receive_message("Hello!", sender="ai")
    Show / hide typing indicator:
        app.show_typing() / app.hide_typing()
    """

    def __init__(self):
        super().__init__()
        self._send_cb = None
        self._messages: list[MessageBubble] = []
        self._typing_row: tk.Frame | None = None
        self._typing_ind: TypingIndicator | None = None
        self._conv_history: list[tuple[str, str]] = []  # (title, first_msg)

        self._setup_window()
        self._setup_styles()
        self._build_layout()
        self._bind_keys()

    # ── Window setup ──────────────────────────────────────────────────────────

    def _setup_window(self):
        self.title("Xyrin Flower · Neural Desktop")
        self.configure(bg=T.BG_DEEPEST)
        self.minsize(T.MIN_WIN_W, T.MIN_WIN_H)
        self.geometry("1100x700")

        # Try to set window icon
        icon_path = ASSETS / "xyrin_icon.svg"
        img = load_svg_as_photo(str(icon_path), size=48)
        if img:
            self._icon_img = img
            try:
                self.iconphoto(True, img)
            except Exception:
                pass

    def _setup_styles(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("Vertical.TScrollbar",
                         background=T.BG_SIDEBAR,
                         troughcolor=T.BG_DEEPEST,
                         arrowcolor=T.TEXT_MUTED,
                         bordercolor=T.BG_DEEPEST,
                         lightcolor=T.BG_SIDEBAR,
                         darkcolor=T.BG_SIDEBAR)

    # ── Layout builder ────────────────────────────────────────────────────────

    def _build_layout(self):
        # Root: sidebar | main
        self._sidebar = self._build_sidebar()
        self._sidebar.pack(side="left", fill="y")

        separator = tk.Frame(self, width=1, bg=T.BORDER_SUBTLE)
        separator.pack(side="left", fill="y")

        main = tk.Frame(self, bg=T.BG_MAIN)
        main.pack(side="left", fill="both", expand=True)

        self._build_topbar(main)
        self._build_chat_area(main)
        self._build_composer(main)

    # ── Sidebar ───────────────────────────────────────────────────────────────

    def _build_sidebar(self) -> tk.Frame:
        sb = tk.Frame(self, width=T.SIDEBAR_W, bg=T.BG_SIDEBAR)
        sb.pack_propagate(False)

        # Logo + wordmark
        logo_row = tk.Frame(sb, bg=T.BG_SIDEBAR)
        logo_row.pack(fill="x", padx=12, pady=(18, 10))

        logo_canvas = tk.Canvas(logo_row, width=36, height=36,
                                 bg=T.BG_SIDEBAR, highlightthickness=0)
        logo_canvas.pack(side="left", padx=(0, 8))

        # Try SVG logo; fall back to canvas draw
        svg_img = load_svg_as_photo(str(ASSETS / "xyrin_logo.svg"), size=36)
        if svg_img:
            self._logo_img = svg_img
            logo_canvas.create_image(0, 0, anchor="nw", image=svg_img)
        else:
            draw_flower_logo(logo_canvas, 0, 0, r=18)

        name_col = tk.Frame(logo_row, bg=T.BG_SIDEBAR)
        name_col.pack(side="left")
        tk.Label(name_col, text="Xyrin", bg=T.BG_SIDEBAR, fg=T.TEXT_PRIMARY,
                  font=(T.FONT_FAMILY, T.FONT_XL, "bold")).pack(anchor="w")
        tk.Label(name_col, text="Flower", bg=T.BG_SIDEBAR, fg=T.TEXT_ACCENT,
                  font=(T.FONT_FAMILY, T.FONT_SM, "italic")).pack(anchor="w")

        # Divider
        tk.Frame(sb, height=1, bg=T.BORDER_SUBTLE).pack(fill="x", padx=12, pady=4)

        # New chat button
        new_btn = tk.Frame(sb, bg=T.ACCENT_BUTTON, cursor="hand2")
        new_btn.pack(fill="x", padx=12, pady=(8, 4))
        tk.Label(new_btn, text="✦  Yeni sohbet", bg=T.ACCENT_BUTTON,
                  fg="#ffffff", font=(T.FONT_FAMILY, T.FONT_MD, "bold"),
                  padx=12, pady=8).pack(anchor="w")
        new_btn.bind("<Enter>", lambda _: new_btn.config(bg=T.ACCENT_BTN_HOV))
        new_btn.bind("<Leave>", lambda _: new_btn.config(bg=T.ACCENT_BUTTON))
        new_btn.bind("<Button-1>", lambda _: self._new_chat())
        for child in new_btn.winfo_children():
            child.bind("<Button-1>", lambda _: self._new_chat())
            child.bind("<Enter>", lambda _: new_btn.config(bg=T.ACCENT_BTN_HOV))
            child.bind("<Leave>", lambda _: new_btn.config(bg=T.ACCENT_BUTTON))

        # Section label
        self._section_label("sb", sb, "ÇALIŞMA ALANI")

        # Workspace items
        self._sidebar_items: list[SidebarItem] = []
        ai_item = SidebarItem(sb, "⬢", "Yerel Yapay Zeka",
                               command=lambda: self._select_workspace("local"),
                               active=True)
        ai_item.pack(fill="x", padx=8, pady=1)
        self._sidebar_items.append(ai_item)

        agent_item = SidebarItem(sb, "○", "XFA Ajan",
                                  command=lambda: self._select_workspace("agent"))
        agent_item.pack(fill="x", padx=8, pady=1)
        self._sidebar_items.append(agent_item)

        # Divider
        tk.Frame(sb, height=1, bg=T.BORDER_SUBTLE).pack(fill="x", padx=12, pady=8)

        # Recent conversations label
        self._section_label("hist", sb, "GEÇMİŞ")

        # Scrollable conversation history
        self._hist_frame = tk.Frame(sb, bg=T.BG_SIDEBAR)
        self._hist_frame.pack(fill="both", expand=True, padx=8)

        # Bottom: start model + settings
        tk.Frame(sb, height=1, bg=T.BORDER_SUBTLE).pack(fill="x", padx=12, pady=4)

        start_btn = SidebarItem(sb, "▶", "Yerel modeli başlat",
                                 command=self._start_model)
        start_btn.pack(fill="x", padx=8, pady=1)

        settings_btn = SidebarItem(sb, "⚙", "Ayarlar ve bağlantılar",
                                    command=self._open_settings)
        settings_btn.pack(fill="x", padx=8, pady=(1, 12))

        return sb

    def _section_label(self, key: str, parent: tk.Widget, text: str):
        tk.Label(parent, text=text, bg=T.BG_SIDEBAR,
                  fg=T.TEXT_MUTED, font=(T.FONT_FAMILY, T.FONT_XS),
                  anchor="w", padx=16).pack(fill="x", pady=(6, 2))

    # ── Top bar ───────────────────────────────────────────────────────────────

    def _build_topbar(self, parent: tk.Frame):
        bar = tk.Frame(parent, bg=T.BG_MAIN, height=52)
        bar.pack(fill="x")
        bar.pack_propagate(False)

        # Left: title
        left = tk.Frame(bar, bg=T.BG_MAIN)
        left.pack(side="left", padx=20, fill="y")

        tk.Label(left, text="✦", bg=T.BG_MAIN, fg=T.ACCENT_LIGHT,
                  font=(T.FONT_FAMILY, T.FONT_XL)).pack(side="left", padx=(0, 8))

        tk.Label(left, text="Neural Chat", bg=T.BG_MAIN, fg=T.TEXT_PRIMARY,
                  font=(T.FONT_FAMILY, T.FONT_XL, "bold")).pack(side="left")

        # Status pill
        status = tk.Frame(left, bg=T.BG_MAIN)
        status.pack(side="left", padx=14)
        tk.Canvas(status, width=10, height=10,
                   bg=T.BG_MAIN, highlightthickness=0).pack(side="left")
        self._status_dot = status.winfo_children()[0]
        self._status_dot.create_oval(1, 1, 9, 9, fill=T.STATUS_ONLINE, outline="")
        tk.Label(status, text="Yerel AI Aktif", bg=T.BG_MAIN,
                  fg=T.STATUS_ONLINE, font=(T.FONT_FAMILY, T.FONT_SM)).pack(side="left")

        # Right: model selector
        right = tk.Frame(bar, bg=T.BG_MAIN)
        right.pack(side="right", padx=20, fill="y")

        model_frame = tk.Frame(right, bg=T.BG_BUBBLE_AI,
                                padx=12, pady=4, cursor="hand2")
        model_frame.pack(side="right")
        tk.Label(model_frame, text="✦", bg=T.BG_BUBBLE_AI,
                  fg=T.ACCENT_LIGHT, font=(T.FONT_FAMILY, T.FONT_MD)).pack(side="left")
        self._model_lbl = tk.Label(model_frame, text="Gemma 3 12B",
                                    bg=T.BG_BUBBLE_AI, fg=T.TEXT_PRIMARY,
                                    font=(T.FONT_FAMILY, T.FONT_MD, "bold"))
        self._model_lbl.pack(side="left", padx=6)
        tk.Label(model_frame, text="▾", bg=T.BG_BUBBLE_AI,
                  fg=T.TEXT_SECONDARY, font=(T.FONT_FAMILY, T.FONT_MD)).pack(side="left")
        model_frame.bind("<Button-1>", self._toggle_model_menu)
        for c in model_frame.winfo_children():
            c.bind("<Button-1>", self._toggle_model_menu)

        # Divider below topbar
        tk.Frame(parent, height=1, bg=T.BORDER_SUBTLE).pack(fill="x")

    # ── Chat area ─────────────────────────────────────────────────────────────

    def _build_chat_area(self, parent: tk.Frame):
        self._chat_scroll = SmoothScrollFrame(parent)
        self._chat_scroll.pack(fill="both", expand=True, padx=0, pady=0)
        self._chat_inner = self._chat_scroll.inner

        # Spacer at top
        tk.Frame(self._chat_inner, height=12, bg=T.BG_MAIN).pack(fill="x")

    # ── Composer ──────────────────────────────────────────────────────────────

    def _build_composer(self, parent: tk.Frame):
        tk.Frame(parent, height=1, bg=T.BORDER_SUBTLE).pack(fill="x")

        outer = tk.Frame(parent, bg=T.BG_INPUT, pady=10)
        outer.pack(fill="x", padx=16, pady=10)

        # Composer border frame
        composer = tk.Frame(outer, bg=T.BORDER_MEDIUM, padx=1, pady=1)
        composer.pack(fill="x")

        inner = tk.Frame(composer, bg=T.BG_INPUT)
        inner.pack(fill="x")

        # Text widget
        self._input = tk.Text(inner, bg=T.BG_INPUT, fg=T.TEXT_PRIMARY,
                               insertbackground=T.ACCENT_LIGHT,
                               font=(T.FONT_FAMILY, T.FONT_MD),
                               relief="flat", padx=14, pady=10,
                               wrap="word", height=2,
                               highlightthickness=0)
        self._input.pack(side="left", fill="both", expand=True)
        self._input.insert("1.0", "")
        self._input.bind("<KeyRelease>", self._on_input_change)
        self._input.bind("<FocusIn>",
                          lambda _: composer.config(bg=T.BORDER_ACCENT))
        self._input.bind("<FocusOut>",
                          lambda _: composer.config(bg=T.BORDER_MEDIUM))

        # Placeholder
        self._placeholder_active = False
        self._set_placeholder()
        self._input.bind("<FocusIn>",  self._clear_placeholder)
        self._input.bind("<FocusOut>", self._restore_placeholder)

        # Bottom row: icons + send button
        bottom_row = tk.Frame(inner, bg=T.BG_INPUT)
        bottom_row.pack(fill="x", padx=8, pady=(0, 6))

        IconButton(bottom_row, icon="📎", bg=T.BG_INPUT).pack(side="left", padx=2)
        IconButton(bottom_row, icon="🌐", bg=T.BG_INPUT).pack(side="left", padx=2)

        self._send_btn = SendButton(bottom_row, command=self._on_send)
        self._send_btn.pack(side="right", padx=4)

        # Status bar
        status_bar = tk.Frame(parent, bg=T.BG_DEEPEST, height=24)
        status_bar.pack(fill="x", side="bottom")
        status_bar.pack_propagate(False)

        self._status_left = tk.Label(status_bar,
                                      text="● Hazır · Offline AI",
                                      bg=T.BG_DEEPEST, fg=T.STATUS_ONLINE,
                                      font=(T.FONT_FAMILY, T.FONT_XS),
                                      padx=14)
        self._status_left.pack(side="left", fill="y")

        tk.Label(status_bar,
                  text="Xyrin Flower  ·  Offline AI Experience",
                  bg=T.BG_DEEPEST, fg=T.TEXT_MUTED,
                  font=(T.FONT_FAMILY, T.FONT_XS)).pack(side="right", padx=14)

    # ── Placeholder ───────────────────────────────────────────────────────────

    def _set_placeholder(self):
        if not self._input.get("1.0", "end-1c"):
            self._placeholder_active = True
            self._input.insert("1.0", "Bir mesaj yazın…")
            self._input.config(fg=T.TEXT_MUTED)

    def _clear_placeholder(self, _):
        if self._placeholder_active:
            self._input.delete("1.0", "end")
            self._input.config(fg=T.TEXT_PRIMARY)
            self._placeholder_active = False

    def _restore_placeholder(self, _):
        if not self._input.get("1.0", "end-1c").strip():
            self._set_placeholder()

    # ── Key bindings ──────────────────────────────────────────────────────────

    def _bind_keys(self):
        self._input.bind("<Return>",        self._on_enter)
        self._input.bind("<Shift-Return>",  self._on_shift_enter)

    def _on_enter(self, event):
        if not event.state & 0x1:   # no shift
            self._on_send()
            return "break"

    def _on_shift_enter(self, event):
        # Allow natural newline
        return None

    def _on_input_change(self, _):
        # Auto-resize the text widget (2–6 lines)
        lines = int(self._input.index("end-1c").split(".")[0])
        lines = max(2, min(lines, 6))
        self._input.config(height=lines)

    # ── Send ──────────────────────────────────────────────────────────────────

    def _on_send(self):
        if self._placeholder_active:
            return
        text = self._input.get("1.0", "end-1c").strip()
        if not text:
            return
        self._input.delete("1.0", "end")
        self._placeholder_active = False
        self._set_placeholder()
        self._input.config(height=2)

        # Add user bubble
        self.append_message("user", text)

        # Fire backend callback
        if self._send_cb:
            threading.Thread(
                target=self._send_cb, args=(text,), daemon=True
            ).start()

    # ── Public API ────────────────────────────────────────────────────────────

    def set_send_callback(self, fn):
        """fn(text: str) → None — called on each user message."""
        self._send_cb = fn

    def append_message(self, sender: str, text: str):
        """Thread-safe. sender = 'user' | 'ai'"""
        self.after(0, self._add_bubble, sender, text)

    def _add_bubble(self, sender: str, text: str):
        bubble = MessageBubble(self._chat_inner, sender=sender, text=text)
        bubble.pack(fill="x", padx=16, pady=4)
        self._messages.append(bubble)
        self._chat_scroll.bind_mousewheel_to(bubble)
        self._chat_scroll.scroll_to_bottom()
        # Save to history (first message starts a conversation)
        if sender == "user" and len(self._messages) == 1:
            self._add_history_entry(text[:40] + ("…" if len(text) > 40 else ""))

    # backward-compat alias
    def receive_message(self, text: str, sender: str = "ai"):
        self.append_message(sender, text)

    def show_typing(self):
        """Show animated typing indicator."""
        self.after(0, self._show_typing_ui)

    def hide_typing(self):
        """Remove typing indicator."""
        self.after(0, self._hide_typing_ui)

    def _show_typing_ui(self):
        if self._typing_row:
            return
        self._typing_row = tk.Frame(self._chat_inner, bg=T.BG_MAIN)
        self._typing_row.pack(fill="x", padx=20, pady=4, anchor="w")

        # Mini avatar
        av = tk.Canvas(self._typing_row, width=28, height=28,
                        bg=T.BG_MAIN, highlightthickness=0)
        av.create_oval(2, 2, 26, 26, fill="#1e1740", outline=T.BORDER_ACCENT)
        av.create_oval(7, 7, 21, 21, fill=T.ACCENT_VIOLET, outline="")
        av.pack(side="left", padx=(0, 8))

        self._typing_ind = TypingIndicator(self._typing_row)
        self._typing_ind.pack(side="left")
        self._typing_ind.start()
        self._chat_scroll.scroll_to_bottom()

    def _hide_typing_ui(self):
        if self._typing_row:
            if self._typing_ind:
                self._typing_ind.stop()
            self._typing_row.destroy()
            self._typing_row = None
            self._typing_ind = None

    def set_status(self, text: str, color: str = T.STATUS_ONLINE):
        self.after(0, lambda: self._status_left.config(
            text=f"● {text}", fg=color))

    def set_model_name(self, name: str):
        self.after(0, lambda: self._model_lbl.config(text=name))

    # ── History ───────────────────────────────────────────────────────────────

    def _add_history_entry(self, title: str):
        item = SidebarItem(self._hist_frame, "💬", title)
        item.pack(fill="x", pady=1)

    def _new_chat(self):
        # Clear messages
        for child in self._chat_inner.winfo_children():
            child.destroy()
        tk.Frame(self._chat_inner, height=12, bg=T.BG_MAIN).pack(fill="x")
        self._messages.clear()
        self._typing_row = None
        self._typing_ind = None

    # ── Workspace selection ───────────────────────────────────────────────────

    def _select_workspace(self, key: str):
        for item in self._sidebar_items:
            item.set_active(False)
        idx = 0 if key == "local" else 1
        if idx < len(self._sidebar_items):
            self._sidebar_items[idx].set_active(True)

    # ── Stubs for model menu / settings / start ───────────────────────────────

    def _toggle_model_menu(self, _=None):
        # Can be wired to a Toplevel popup if desired
        pass

    def _start_model(self):
        self.set_status("Model başlatılıyor…", T.ACCENT_LIGHT)

    def _open_settings(self):
        # Placeholder — wire to settings Toplevel in main app
        pass
