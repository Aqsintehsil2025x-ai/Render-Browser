"""
Minimal SVG → Tkinter PhotoImage helper.
Falls back to a drawn canvas placeholder when no SVG library is present.
Priority: cairosvg → svglib/reportlab → built-in canvas drawing.
"""
from __future__ import annotations
import tkinter as tk
from pathlib import Path


def _try_cairosvg(svg_path: str, size: int) -> bytes | None:
    try:
        import cairosvg  # type: ignore
        return cairosvg.svg2png(url=svg_path, output_width=size, output_height=size)
    except Exception:
        return None


def _try_svglib(svg_path: str, size: int):
    try:
        from svglib.svglib import svg2rlg  # type: ignore
        from reportlab.graphics import renderPM  # type: ignore
        import io, PIL.Image, PIL.ImageTk  # type: ignore
        drawing = svg2rlg(svg_path)
        if drawing:
            scale = size / max(drawing.width, drawing.height)
            drawing.width *= scale
            drawing.height *= scale
            drawing.transform = (scale, 0, 0, scale, 0, 0)
            buf = io.BytesIO()
            renderPM.drawToFile(drawing, buf, fmt="PNG")
            buf.seek(0)
            img = PIL.Image.open(buf).convert("RGBA")
            return PIL.ImageTk.PhotoImage(img)
    except Exception:
        return None


def load_svg_as_photo(svg_path: str, size: int = 32) -> tk.PhotoImage | None:
    """Return a Tkinter PhotoImage from an SVG file, or None on failure."""
    path = str(Path(svg_path).resolve())

    # Try cairosvg (best quality)
    png_bytes = _try_cairosvg(path, size)
    if png_bytes:
        try:
            import io, PIL.Image, PIL.ImageTk  # type: ignore
            img = PIL.Image.open(io.BytesIO(png_bytes)).convert("RGBA")
            return PIL.ImageTk.PhotoImage(img)
        except Exception:
            pass

    # Try svglib
    result = _try_svglib(path, size)
    if result:
        return result

    return None


def draw_flower_logo(canvas: tk.Canvas, x: int, y: int, r: int = 18) -> None:
    """
    Draw a simplified Xyrin Flower logo onto a Tkinter Canvas.
    Used as fallback when no SVG renderer is available.
    """
    import math

    cx, cy = x + r, y + r

    # Stem
    canvas.create_line(cx, cy + r * 0.6, cx - 2, cy + r * 1.8,
                        fill="#5b21b6", width=2, smooth=True)

    # Leaf
    canvas.create_polygon(
        cx - 2, cy + r * 1.2,
        cx - r * 0.8, cy + r * 0.9,
        cx - r * 0.9, cy + r * 0.6,
        cx - 2, cy + r * 1.0,
        smooth=True, fill="#4c1d95", outline=""
    )

    petal_colors = ["#a78bfa", "#c4b5fd", "#7c3aed"]
    num_petals = 6
    petal_len = r * 0.95
    petal_w = r * 0.32

    for i in range(num_petals):
        angle = math.radians(i * 60)
        px = cx + math.sin(angle) * petal_len * 0.5
        py = cy - math.cos(angle) * petal_len * 0.5
        color = petal_colors[i % len(petal_colors)]
        pts = []
        for t in range(13):
            a = angle + math.radians(t * 30 - 180)
            d = petal_len * 0.5 * math.sin(math.radians(t * 15))
            nx = px + math.sin(a) * petal_w * d / (petal_len * 0.5 + 0.001)
            ny = py - math.cos(a) * petal_w * d / (petal_len * 0.5 + 0.001)
            pts.extend([nx, ny])
        # Simple oval petal
        ex = cx + math.sin(angle) * petal_len
        ey = cy - math.cos(angle) * petal_len
        canvas.create_oval(
            min(cx, ex) - petal_w / 2, min(cy, ey) - petal_w / 2,
            max(cx, ex) + petal_w / 2, max(cy, ey) + petal_w / 2,
            fill=color, outline="", stipple=""
        )

    # Center
    canvas.create_oval(cx - r * 0.28, cy - r * 0.28,
                        cx + r * 0.28, cy + r * 0.28,
                        fill="#ddd6fe", outline="#c4b5fd", width=1)
    canvas.create_oval(cx - r * 0.12, cy - r * 0.12,
                        cx + r * 0.12, cy + r * 0.12,
                        fill="#ffffff", outline="")
