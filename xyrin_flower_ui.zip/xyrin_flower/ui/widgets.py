"""
Xyrin Flower — Custom Tkinter Widgets
Rounded message bubbles, typing indicator, smooth canvas scroller.
"""
from __future__ import annotations
import tkinter as tk
from tkinter import font as tkfont
import time, math
from ui import theme as T


# ─────────────────────────────────────────────────────────────────────────────
#  RoundedFrame  — canvas-drawn rounded rectangle acting as a frame
# ─────────────────────────────────────────────────────────────────────────────

class RoundedFrame(tk.Canvas):
    """A canvas that draws a rounded-rect background and hosts child widgets."""

    def __init__(self, master, bg_color: str, radius: int = 10, **kwargs):
        super().__init__(master, bg=T.BG_MAIN, highlightthickness=0, **kwargs)
        self._bg = bg_color
        self._r = radius
        self._rect_id = None
        self.bind("<Configure>", self._redraw)

    def _redraw(self, _=None):
        self.delete("bg_rect")
        w, h = self.winfo_width(), self.winfo_height()
        if w < 2 or h < 2:
            return
        r = self._r
        # Approximate rounded rect with polygon + arcs
        self.create_polygon(
            r, 0, w - r, 0,
            w, 0, w, r,
            w, h - r, w, h,
            w - r, h, r, h,
            0, h, 0, h - r,
            0, r, 0, 0,
            r, 0,
            fill=self._bg, outline=T.BORDER_SUBTLE, width=1,
            smooth=True, tags="bg_rect"
        )
        self.tag_lower("bg_rect")


# ─────────────────────────────────────────────────────────────────────────────
#  MessageBubble
# ─────────────────────────────────────────────────────────────────────────────

class MessageBubble(tk.Frame):
    """
    A single chat message row.
    sender: "user" | "ai"
    """

    def __init__(self, master, sender: str, text: str, **kwargs):
        super().__init__(master, bg=T.BG_MAIN, **kwargs)
        self.sender = sender
        self._build(sender, text)

    def _build(self, sender: str, text: str):
        is_user = (sender == "user")

        # Avatar circle (canvas)
        avatar = tk.Canvas(self, width=32, height=32,
                            bg=T.BG_MAIN, highlightthickness=0)
        if is_user:
            avatar.create_oval(2, 2, 30, 30, fill="#2d2660", outline=T.BORDER_MEDIUM)
            avatar.create_text(16, 16, text="S", fill=T.ACCENT_LIGHT,
                                font=(T.FONT_FAMILY, T.FONT_MD, "bold"))
        else:
            # Violet flower dot
            avatar.create_oval(2, 2, 30, 30, fill="#1e1740", outline=T.BORDER_ACCENT)
            avatar.create_oval(8, 8, 24, 24, fill=T.ACCENT_VIOLET, outline="")
            avatar.create_oval(12, 12, 20, 20, fill="#ddd6fe", outline="")

        # Bubble
        bubble_bg = T.BG_BUBBLE_ME if is_user else T.BG_BUBBLE_AI
        sender_name = "Sen" if is_user else "XFA / AI"
        name_color  = T.TEXT_SECONDARY if is_user else T.ACCENT_LIGHT

        content = tk.Frame(self, bg=T.BG_MAIN)

        name_lbl = tk.Label(content, text=sender_name,
                             bg=T.BG_MAIN, fg=name_color,
                             font=(T.FONT_FAMILY, T.FONT_SM, "bold"))
        name_lbl.pack(anchor="w", pady=(0, 2))

        bubble = RoundedFrame(content, bg_color=bubble_bg, radius=12,
                               width=10, height=10)
        bubble.pack(anchor="w", fill="x")

        msg_lbl = tk.Label(bubble, text=text, wraplength=T.MSG_MAX_W,
                            justify="left", bg=bubble_bg,
                            fg=T.TEXT_PRIMARY,
                            font=(T.FONT_FAMILY, T.FONT_MD),
                            padx=14, pady=10)
        bubble.create_window(0, 0, anchor="nw", window=msg_lbl, tags="msg")
        msg_lbl.update_idletasks()
        bubble.config(width=msg_lbl.winfo_reqwidth(),
                       height=msg_lbl.winfo_reqheight())

        if is_user:
            avatar.pack(side="right", padx=(8, 0), pady=4, anchor="n")
            content.pack(side="right", padx=(0, 4), pady=4, anchor="n", fill="x", expand=True)
        else:
            avatar.pack(side="left", padx=(0, 8), pady=4, anchor="n")
            content.pack(side="left", padx=(0, 4), pady=4, anchor="n", fill="x", expand=True)

    def update_text(self, text: str):
        """Replace the visible text (used for streaming)."""
        # Destroy and rebuild is acceptable for rare streaming updates
        for w in self.winfo_children():
            w.destroy()
        self._build(self.sender, text)


# ─────────────────────────────────────────────────────────────────────────────
#  TypingIndicator
# ─────────────────────────────────────────────────────────────────────────────

class TypingIndicator(tk.Canvas):
    """Three pulsing dots shown while AI is generating."""

    DOT_R    = 4
    DOT_GAP  = 10
    NUM_DOTS = 3
    PERIOD   = 900   # ms for one full cycle

    def __init__(self, master, **kwargs):
        w = (self.DOT_R * 2 + self.DOT_GAP) * self.NUM_DOTS + 20
        super().__init__(master, width=w, height=24,
                          bg=T.BG_MAIN, highlightthickness=0, **kwargs)
        self._dots: list[int] = []
        self._running = False
        self._t0 = 0.0
        self._create_dots()

    def _create_dots(self):
        y = 12
        for i in range(self.NUM_DOTS):
            x = 10 + i * (self.DOT_R * 2 + self.DOT_GAP) + self.DOT_R
            did = self.create_oval(x - self.DOT_R, y - self.DOT_R,
                                    x + self.DOT_R, y + self.DOT_R,
                                    fill=T.ACCENT_VIOLET, outline="")
            self._dots.append(did)

    def start(self):
        self._running = True
        self._t0 = time.time()
        self._animate()

    def stop(self):
        self._running = False

    def _animate(self):
        if not self._running:
            return
        t = (time.time() - self._t0) * 1000  # ms
        for i, did in enumerate(self._dots):
            phase = (t - i * (self.PERIOD / self.NUM_DOTS)) % self.PERIOD
            # brightness: 0→1→0
            brightness = 0.5 + 0.5 * math.sin(math.pi * phase / self.PERIOD)
            r = int(0x7c + (0xc4 - 0x7c) * brightness)
            g = int(0x3a + (0xb5 - 0x3a) * brightness)
            b = int(0xed + (0xfd - 0xed) * brightness)
            color = f"#{r:02x}{g:02x}{b:02x}"
            self.itemconfig(did, fill=color)
        self.after(40, self._animate)


# ─────────────────────────────────────────────────────────────────────────────
#  SmoothScrollFrame  — canvas + scrollbar acting as a scrollable container
# ─────────────────────────────────────────────────────────────────────────────

class SmoothScrollFrame(tk.Frame):
    """
    A vertically scrollable frame with mouse-wheel support.
    Children are added to self.inner.
    """

    def __init__(self, master, **kwargs):
        super().__init__(master, bg=T.BG_MAIN, **kwargs)
        self._setup()

    def _setup(self):
        self.canvas = tk.Canvas(self, bg=T.BG_MAIN,
                                 highlightthickness=0, bd=0)
        self.scrollbar = tk.Scrollbar(self, orient="vertical",
                                       command=self.canvas.yview,
                                       bg=T.BG_SIDEBAR,
                                       troughcolor=T.BG_DEEPEST,
                                       activebackground=T.ACCENT_VIOLET,
                                       width=6)
        self.inner = tk.Frame(self.canvas, bg=T.BG_MAIN)
        self._win_id = self.canvas.create_window(
            (0, 0), window=self.inner, anchor="nw"
        )
        self.canvas.configure(yscrollcommand=self.scrollbar.set)

        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

        self.inner.bind("<Configure>", self._on_inner_configure)
        self.canvas.bind("<Configure>", self._on_canvas_configure)

        # Mouse-wheel bindings
        self.canvas.bind("<MouseWheel>", self._on_mousewheel)
        self.canvas.bind("<Button-4>",   self._on_mousewheel)
        self.canvas.bind("<Button-5>",   self._on_mousewheel)
        self.inner.bind("<MouseWheel>",  self._on_mousewheel)
        self.inner.bind("<Button-4>",    self._on_mousewheel)
        self.inner.bind("<Button-5>",    self._on_mousewheel)

    def _on_inner_configure(self, _):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _on_canvas_configure(self, event):
        self.canvas.itemconfig(self._win_id, width=event.width)

    def _on_mousewheel(self, event):
        if event.num == 4:
            self.canvas.yview_scroll(-T.SCROLL_SPEED, "units")
        elif event.num == 5:
            self.canvas.yview_scroll(T.SCROLL_SPEED, "units")
        else:
            self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    def scroll_to_bottom(self):
        self.canvas.update_idletasks()
        self.canvas.yview_moveto(1.0)

    def bind_mousewheel_to(self, widget: tk.Widget):
        """Recursively bind mousewheel events so inner children scroll the pane."""
        widget.bind("<MouseWheel>", self._on_mousewheel)
        widget.bind("<Button-4>",   self._on_mousewheel)
        widget.bind("<Button-5>",   self._on_mousewheel)
        for child in widget.winfo_children():
            self.bind_mousewheel_to(child)


# ─────────────────────────────────────────────────────────────────────────────
#  SidebarItem
# ─────────────────────────────────────────────────────────────────────────────

class SidebarItem(tk.Frame):
    """A clickable sidebar row with icon text, label, and hover highlight."""

    def __init__(self, master, icon: str, label: str,
                 command=None, active: bool = False, **kwargs):
        super().__init__(master, bg=T.BG_SIDEBAR,
                          cursor="hand2", **kwargs)
        self._active = active
        self._cmd = command
        self._build(icon, label)
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self.bind("<Button-1>", self._on_click)
        for child in self.winfo_children():
            child.bind("<Button-1>", self._on_click)

    def _build(self, icon: str, label: str):
        self._icon_lbl = tk.Label(self, text=icon, width=2,
                                   bg=T.BG_SIDEBAR, fg=T.ACCENT_LIGHT,
                                   font=(T.FONT_FAMILY, T.FONT_MD))
        self._icon_lbl.pack(side="left", padx=(10, 4), pady=6)

        self._text_lbl = tk.Label(self, text=label,
                                   bg=T.BG_SIDEBAR, fg=T.TEXT_PRIMARY,
                                   font=(T.FONT_FAMILY, T.FONT_MD),
                                   anchor="w")
        self._text_lbl.pack(side="left", fill="x", expand=True, pady=6)
        self._update_colors()

    def _update_colors(self):
        bg = T.BG_ACTIVE if self._active else T.BG_SIDEBAR
        fg = T.TEXT_ACCENT if self._active else T.TEXT_PRIMARY
        self.config(bg=bg)
        self._icon_lbl.config(bg=bg)
        self._text_lbl.config(bg=bg, fg=fg)

    def _on_enter(self, _):
        if not self._active:
            self.config(bg=T.BG_HOVER)
            self._icon_lbl.config(bg=T.BG_HOVER)
            self._text_lbl.config(bg=T.BG_HOVER)

    def _on_leave(self, _):
        self._update_colors()

    def _on_click(self, _):
        if self._cmd:
            self._cmd()

    def set_active(self, active: bool):
        self._active = active
        self._update_colors()


# ─────────────────────────────────────────────────────────────────────────────
#  IconButton
# ─────────────────────────────────────────────────────────────────────────────

class IconButton(tk.Label):
    """Small icon-only button with hover glow."""

    def __init__(self, master, icon: str, tooltip: str = "",
                 command=None, size: int = T.FONT_LG, **kwargs):
        super().__init__(master, text=icon,
                          font=(T.FONT_FAMILY, size),
                          fg=T.TEXT_SECONDARY,
                          cursor="hand2",
                          **kwargs)
        self._cmd = command
        self._tip = tooltip
        self.bind("<Enter>", lambda _: self.config(fg=T.ACCENT_LIGHT))
        self.bind("<Leave>", lambda _: self.config(fg=T.TEXT_SECONDARY))
        self.bind("<Button-1>", lambda _: self._cmd() if self._cmd else None)


# ─────────────────────────────────────────────────────────────────────────────
#  SendButton
# ─────────────────────────────────────────────────────────────────────────────

class SendButton(tk.Canvas):
    """Rounded violet send button."""

    def __init__(self, master, command=None, **kwargs):
        super().__init__(master, width=80, height=36,
                          bg=T.BG_INPUT, highlightthickness=0, **kwargs)
        self._cmd = command
        self._hovered = False
        self._draw(T.ACCENT_BUTTON)
        self.bind("<Enter>",    self._on_enter)
        self.bind("<Leave>",    self._on_leave)
        self.bind("<Button-1>", self._on_click)

    def _draw(self, fill: str):
        self.delete("all")
        w, h = 80, 36
        r = 8
        self.create_polygon(
            r, 0, w - r, 0, w, 0, w, r,
            w, h - r, w, h, w - r, h, r, h,
            0, h, 0, h - r, 0, r, 0, 0, r, 0,
            fill=fill, outline=T.BORDER_ACCENT, width=1, smooth=True
        )
        self.create_text(40, 18, text="Gönder ↵",
                          fill="#ffffff", font=(T.FONT_FAMILY, T.FONT_SM, "bold"))

    def _on_enter(self, _):
        self._draw(T.ACCENT_BTN_HOV)

    def _on_leave(self, _):
        self._draw(T.ACCENT_BUTTON)

    def _on_click(self, _):
        if self._cmd:
            self._cmd()
