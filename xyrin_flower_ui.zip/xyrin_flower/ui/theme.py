"""
Xyrin Flower — Design Tokens
Dark navy · blue-violet palette matching the original aesthetic.
"""

# ── Palette ───────────────────────────────────────────────────────────────────
BG_DEEPEST   = "#080714"   # window root bg
BG_SIDEBAR   = "#0d0b1e"   # sidebar panel
BG_MAIN      = "#0f0d22"   # chat area
BG_BUBBLE_AI = "#181430"   # XFA message bubble
BG_BUBBLE_ME = "#1e1a3d"   # user message bubble
BG_INPUT     = "#13102a"   # composer background
BG_HOVER     = "#1a1735"   # sidebar item hover
BG_ACTIVE    = "#251f4a"   # sidebar item active

BORDER_SUBTLE  = "#1f1a40"
BORDER_MEDIUM  = "#2d2660"
BORDER_ACCENT  = "#4c3d9e"

ACCENT_VIOLET  = "#7c3aed"
ACCENT_LIGHT   = "#a78bfa"
ACCENT_GLOW    = "#c4b5fd"
ACCENT_BUTTON  = "#6d28d9"
ACCENT_BTN_HOV = "#7c3aed"

TEXT_PRIMARY   = "#e2e0f0"
TEXT_SECONDARY = "#9490b8"
TEXT_MUTED     = "#5c5880"
TEXT_ACCENT    = "#c4b5fd"

STATUS_ONLINE  = "#34d399"
STATUS_OFFLINE = "#6b7280"

# ── Typography ────────────────────────────────────────────────────────────────
FONT_FAMILY   = "Inter"
FONT_FALLBACK = "Segoe UI"
FONT_MONO     = "JetBrains Mono"

FONT_XS  = 9
FONT_SM  = 10
FONT_MD  = 11
FONT_LG  = 13
FONT_XL  = 16
FONT_2XL = 20
FONT_3XL = 26

# ── Sizing ────────────────────────────────────────────────────────────────────
SIDEBAR_W     = 240
MIN_WIN_W     = 820
MIN_WIN_H     = 580
CORNER_RADIUS = 8   # used where ttk/canvas allows
MSG_MAX_W     = 580
INPUT_H_MIN   = 48
INPUT_H_MAX   = 140
SCROLL_SPEED  = 3

# ── Timing (ms) ───────────────────────────────────────────────────────────────
ANIM_FAST = 120
ANIM_MID  = 220
ANIM_SLOW = 380
