#!/usr/bin/env python3
"""
Xyrin Flower — Application entry point
=======================================
This file replaces (or wraps) the original main.py.

HOW TO INTEGRATE WITH YOUR EXISTING BACKEND
--------------------------------------------
1.  Import and call your existing AI/model functions instead of
    the placeholder `generate_reply()` below.
2.  Do NOT modify anything inside ui/ — it is purely the visual layer.
3.  The two key hooks are:
        app.set_send_callback(fn)      # fn(user_text: str)
        app.receive_message(text, sender="ai")

Minimal wiring example (replace with your real llama.cpp / API call):

    import subprocess, threading

    def on_user_message(text: str):
        app.show_typing()
        # --- your existing generation call here ---
        result = my_existing_generate(text)
        # -----------------------------------------
        app.hide_typing()
        app.receive_message(result, sender="ai")

    app.set_send_callback(on_user_message)
"""
from __future__ import annotations
import time, threading

from ui.app_ui import XyrinUI


# ─────────────────────────────────────────────────────────────────────────────
#  PLACEHOLDER  — replace with your real backend call
# ─────────────────────────────────────────────────────────────────────────────

def generate_reply(user_text: str) -> str:
    """
    STUB: replace the body of this function with your existing
    llama.cpp / Ollama / API call.
    """
    time.sleep(1.2)  # simulate latency
    return (
        f"Merhaba! '{user_text[:30]}…' mesajınızı aldım. "
        "Gerçek model entegrasyonu için bu fonksiyonu kendi "
        "AI arka ucunuzla değiştirin."
    )


def on_user_message(text: str):
    """Called by the UI whenever the user sends a message."""
    app.show_typing()
    app.set_status("Yanıt üretiliyor…")

    reply = generate_reply(text)          # ← swap this call

    app.hide_typing()
    app.receive_message(reply, sender="ai")
    app.set_status("Hazır · Offline AI")


# ─────────────────────────────────────────────────────────────────────────────
#  Bootstrap
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    app = XyrinUI()
    app.set_send_callback(on_user_message)

    # Optional: show welcome message on start
    def _welcome():
        time.sleep(0.3)
        app.receive_message(
            "Salam! Ben Xyrin. Size nasıl yardımcı olabilirim?",
            sender="ai"
        )
    threading.Thread(target=_welcome, daemon=True).start()

    app.mainloop()
